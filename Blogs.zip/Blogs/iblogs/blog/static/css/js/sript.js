tinymce.init({
    selector: 'textarea'
});